/**
 * Deckify AI backend — replaces the Convex deployment.
 *
 * Run alongside x402-demo-server (which keeps handling its own payment
 * path unchanged): this server owns auth, decks, projects, payments
 * (the Algorand wallet-connect path), nfts, comments, settings, admin,
 * and GitHub repo ingestion.
 */

import { Hono } from "hono";
import { cors } from "hono/cors";
import dotenv from "dotenv";
import { pathToFileURL } from "node:url";

import { adminRoutes } from "./routes/admin.js";
import { authRoutes } from "./routes/auth.js";
import { billingRoutes } from "./routes/billing.js";
import { commentsRoutes } from "./routes/comments.js";
import { decksRoutes } from "./routes/decks.js";
import { githubRoutes } from "./routes/github.js";
import { nftsRoutes } from "./routes/nfts.js";
import { paymentsRoutes } from "./routes/payments.js";
import { settingsRoutes } from "./routes/settings.js";
import { HttpError } from "./lib/http.js";

dotenv.config();

const app = new Hono();
const PORT = parseInt(process.env.PORT ?? "8787", 10);
const FRONTEND_URL = process.env.FRONTEND_URL ?? "http://localhost:5173";

// On Vercel the frontend and this API share one domain, so requests are
// same-origin and CORS never applies. Setting CORS_DISABLED=true skips the
// middleware entirely; otherwise it keeps guarding the split local setup
// (Vite on :5173 talking to this server on :8787).
if (process.env.CORS_DISABLED !== "true") {
  app.use(
    "*",
    cors({
      origin: FRONTEND_URL,
      allowMethods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
      allowHeaders: ["Content-Type", "Authorization"],
    }),
  );
}

app.get("/", (c) =>
  c.json({ name: "Deckify AI backend", version: "1.0.0", status: "running" }),
);

app.get("/api/health", (c) => c.json({ ok: true }));

app.route("/api/auth", authRoutes);
app.route("/api/decks", decksRoutes);
app.route("/api/payments", paymentsRoutes);
app.route("/api/nfts", nftsRoutes);
app.route("/api/comments", commentsRoutes);
app.route("/api/admin", adminRoutes);
app.route("/api/settings", settingsRoutes);
app.route("/api/billing", billingRoutes);
app.route("/api/github", githubRoutes);

app.notFound((c) => c.json({ error: "Not found" }, 404));

app.onError((err, c) => {
  if (err instanceof HttpError) {
    return c.json({ error: err.message }, err.status as 400 | 401 | 403 | 404);
  }
  console.error("[server] Unhandled error:", err);
  return c.json({ error: "Internal server error" }, 500);
});

const isMain = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isMain) {
  // Dynamic so that @hono/node-server is never pulled into the Vercel
  // serverless bundle, where there is no long-running process to serve.
  const { serve } = await import("@hono/node-server");
  console.log(`
Deckify AI backend
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Port: ${PORT}
Frontend origin: ${FRONTEND_URL}
Data file: server/data/db.json
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`);
  serve({ fetch: app.fetch, port: PORT });
}

export default app;
