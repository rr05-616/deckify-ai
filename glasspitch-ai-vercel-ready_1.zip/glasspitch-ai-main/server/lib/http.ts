/**
 * Shared HTTP helpers: an Error subclass that carries a status code, plus
 * auth middleware. Every route handler can `throw new HttpError(...)` and
 * the central error handler in index.ts turns it into `{ error: message }`
 * with the right status — mirroring how a thrown `Error` in a Convex
 * function surfaces as `error.message` on the client without extra
 * plumbing in every handler.
 */

import type { Context, Next } from "hono";
import { bearerToken, verifyToken } from "./auth.js";
import { get } from "./db.js";
import type { PublicUser } from "./auth.js";

export class HttpError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export const notSignedIn = () => new HttpError("Not signed in", 401);

/** Attaches `c.var.user` when a valid token is present; never throws. */
export async function optionalAuth(c: Context, next: Next): Promise<void> {
  const token = bearerToken(c.req.header("Authorization"));
  const userId = verifyToken(token);
  const user = userId ? get<PublicUser>("users", userId) : null;
  c.set("user", user);
  await next();
}

/** Same as optionalAuth, but rejects with 401 if there is no valid user. */
export async function requireAuth(c: Context, next: Next): Promise<void> {
  const token = bearerToken(c.req.header("Authorization"));
  const userId = verifyToken(token);
  const user = userId ? get<PublicUser>("users", userId) : null;
  if (!user) throw notSignedIn();
  c.set("user", user);
  await next();
}

export function requireAdmin(user: PublicUser | null): PublicUser {
  if (!user) throw notSignedIn();
  if (user.role !== "admin") throw new HttpError("Admins only", 403);
  return user;
}
