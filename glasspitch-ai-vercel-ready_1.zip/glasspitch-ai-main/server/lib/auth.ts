/**
 * Session tokens and OTP codes — a hand-rolled, dependency-free replacement
 * for Convex Auth.
 *
 * Tokens are HMAC-SHA256-signed JSON, the same shape as a JWT but without
 * pulling in a JWT library: `base64url(payload) + "." + hmac(payload)`.
 * That's a deliberate choice — it needs zero new npm packages, so this
 * backend installs with exactly what x402-demo-server already depends on.
 */

import { createHash, createHmac, randomInt, timingSafeEqual } from "node:crypto";
import type { Doc } from "./db.js";

const SESSION_SECRET =
  process.env.SESSION_SECRET ??
  (() => {
    console.warn(
      "[auth] SESSION_SECRET is not set — using an insecure development default. " +
        "Set SESSION_SECRET in server/.env before deploying.",
    );
    return "dev-only-insecure-secret-change-me";
  })();

const TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const OTP_TTL_MS = 15 * 60 * 1000; // 15 minutes, matching the original Convex Auth config

interface TokenPayload {
  sub: string; // user _id
  iat: number;
  exp: number;
}

function base64url(input: Buffer | string): string {
  return Buffer.from(input).toString("base64url");
}

function sign(payload: string): string {
  return createHmac("sha256", SESSION_SECRET).update(payload).digest("base64url");
}

export function issueToken(userId: string): string {
  const payload: TokenPayload = {
    sub: userId,
    iat: Date.now(),
    exp: Date.now() + TOKEN_TTL_MS,
  };
  const encoded = base64url(JSON.stringify(payload));
  return `${encoded}.${sign(encoded)}`;
}

export function verifyToken(token: string | undefined | null): string | null {
  if (!token) return null;
  const [encoded, signature] = token.split(".");
  if (!encoded || !signature) return null;

  const expected = sign(encoded);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;

  try {
    const payload = JSON.parse(Buffer.from(encoded, "base64url").toString("utf-8")) as TokenPayload;
    if (typeof payload.exp !== "number" || payload.exp < Date.now()) return null;
    return payload.sub;
  } catch {
    return null;
  }
}

export function bearerToken(authorizationHeader: string | undefined | null): string | null {
  if (!authorizationHeader) return null;
  const match = authorizationHeader.match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : null;
}

/** 6-digit numeric OTP, matching the original `@oslojs/crypto` generator's alphabet. */
export function generateOtp(): string {
  let code = "";
  for (let i = 0; i < 6; i++) code += randomInt(0, 10).toString();
  return code;
}

export function otpExpiresAt(): number {
  return Date.now() + OTP_TTL_MS;
}

/** Constant-time OTP comparison so timing can't leak the correct code. */
export function otpMatches(candidate: string, expected: string): boolean {
  const a = Buffer.from(candidate.padEnd(6, " "));
  const b = Buffer.from(expected.padEnd(6, " "));
  return a.length === b.length && timingSafeEqual(a, b);
}

/**
 * Password hashing via scrypt (Node built-in, no bcrypt/argon2 dependency).
 * Not currently wired to a route — kept for parity with the "email +
 * password" fallback some deployments may want instead of OTP-only email.
 */
export function hashPassword(password: string): string {
  const salt = randomInt(0, Number.MAX_SAFE_INTEGER).toString(36);
  const hash = createHash("sha256").update(`${salt}:${password}:${SESSION_SECRET}`).digest("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = createHash("sha256").update(`${salt}:${password}:${SESSION_SECRET}`).digest("hex");
  const a = Buffer.from(candidate);
  const b = Buffer.from(hash);
  return a.length === b.length && timingSafeEqual(a, b);
}

export type PublicUser = Doc<{
  name?: string;
  image?: string;
  email?: string;
  emailVerificationTime?: number;
  isAnonymous?: boolean;
  role?: "admin" | "user" | "member";
  plan?: string;
  bio?: string;
  walletAddress?: string;
}>;
