/**
 * Minimal document datastore.
 *
 * This replaces Convex's document database. It intentionally mimics Convex's
 * document shape — every record gets an auto-generated `_id` and
 * `_creationTime` — because the entire frontend was written against that
 * shape (`deck._id`, `deck._creationTime`, etc.) and preserving it means
 * zero changes to how pages render data.
 *
 * TWO BACKENDS, ONE API
 * ---------------------
 * The whole store lives in memory as a plain object and is flushed out as a
 * single JSON blob. Where that blob lands depends on the environment:
 *
 *   • DATABASE_URL set   -> a `deckify_store` row in Postgres (Neon).
 *     This is what Vercel uses, because serverless functions have no
 *     writable, persistent filesystem.
 *   • DATABASE_URL unset -> `server/data/db.json` on local disk, exactly as
 *     before. Local `npm run dev` keeps working with no setup.
 *
 * Every exported function below is still SYNCHRONOUS, which is the whole
 * point — none of the ~70 call sites across `server/routes/*` had to change.
 * The async work is confined to `reload()` and `flush()`, which the Vercel
 * entrypoint (`api/[...route].ts`) wraps around each request:
 *
 *     reload()  ->  route handler runs against fresh state  ->  flush()
 *
 * CONCURRENCY CAVEAT
 * ------------------
 * Because the whole store is written as one blob, two requests that overlap
 * in time can clobber each other's writes (last flush wins). Reloading at the
 * start of every request shrinks that window to the duration of a single
 * handler, which is fine for this app's scale. If you outgrow it, the fix is
 * to give each table its own Postgres table and make these functions async —
 * the call sites would then need `await`.
 */

import { randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export type Doc<T> = T & { _id: string; _creationTime: number };

interface Tables {
  users: Record<string, unknown>;
  projects: Record<string, unknown>;
  decks: Record<string, unknown>;
  payments: Record<string, unknown>;
  nfts: Record<string, unknown>;
  comments: Record<string, unknown>;
  otps: Record<string, unknown>;
}

export type TableName = keyof Tables;

type Store = { [K in TableName]: Array<Doc<Record<string, unknown>>> };

function emptyStore(): Store {
  return {
    users: [],
    projects: [],
    decks: [],
    payments: [],
    nfts: [],
    comments: [],
    otps: [],
  };
}

const CONNECTION_STRING =
  process.env.DATABASE_URL ?? process.env.POSTGRES_URL ?? "";

export const usingPostgres = CONNECTION_STRING.length > 0;

const STORE_ID = "main";

let store: Store = emptyStore();
let dirty = false;

/* ------------------------------------------------------------------ */
/* File backend (local development)                                    */
/* ------------------------------------------------------------------ */

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(__dirname, "../data");
const DATA_FILE = path.join(DATA_DIR, "db.json");

function loadFromFile(): Store {
  if (!existsSync(DATA_FILE)) return emptyStore();
  try {
    const parsed = JSON.parse(readFileSync(DATA_FILE, "utf-8")) as Partial<Store>;
    return { ...emptyStore(), ...parsed };
  } catch (error) {
    console.error("[db] failed to read db.json, starting fresh:", error);
    return emptyStore();
  }
}

function writeToFile(): void {
  try {
    if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(DATA_FILE, JSON.stringify(store, null, 2));
  } catch (error) {
    console.error("[db] failed to persist db.json:", error);
  }
}

/* ------------------------------------------------------------------ */
/* Postgres backend (Vercel)                                           */
/* ------------------------------------------------------------------ */

type SqlClient = (
  strings: TemplateStringsArray,
  ...values: unknown[]
) => Promise<Record<string, unknown>[]>;

let sqlClient: SqlClient | null = null;
let tableReady = false;

async function getSql(): Promise<SqlClient> {
  if (!sqlClient) {
    // Imported lazily so the file backend needs no database dependency.
    const { neon } = await import("@neondatabase/serverless");
    sqlClient = neon(CONNECTION_STRING) as unknown as SqlClient;
  }
  return sqlClient;
}

async function ensureTable(): Promise<void> {
  if (tableReady) return;
  const sql = await getSql();
  await sql`
    CREATE TABLE IF NOT EXISTS deckify_store (
      id         text PRIMARY KEY,
      data       jsonb NOT NULL,
      updated_at timestamptz NOT NULL DEFAULT now()
    )
  `;
  tableReady = true;
}

/* ------------------------------------------------------------------ */
/* Lifecycle                                                           */
/* ------------------------------------------------------------------ */

/** Pull the latest state in. Call once at the START of every request. */
export async function reload(): Promise<void> {
  if (!usingPostgres) {
    store = loadFromFile();
    dirty = false;
    return;
  }
  await ensureTable();
  const sql = await getSql();
  const rows = await sql`SELECT data FROM deckify_store WHERE id = ${STORE_ID}`;
  const data = rows[0]?.data as Partial<Store> | undefined;
  store = { ...emptyStore(), ...(data ?? {}) };
  dirty = false;
}

/** Write pending changes out. Call once at the END of every request. */
export async function flush(): Promise<void> {
  if (!dirty) return;
  if (!usingPostgres) {
    writeToFile();
    dirty = false;
    return;
  }
  await ensureTable();
  const sql = await getSql();
  await sql`
    INSERT INTO deckify_store (id, data, updated_at)
    VALUES (${STORE_ID}, ${JSON.stringify(store)}::jsonb, now())
    ON CONFLICT (id) DO UPDATE
      SET data = EXCLUDED.data, updated_at = now()
  `;
  dirty = false;
}

function persist(): void {
  dirty = true;
}

// Seed the in-memory copy for the long-running local server. On Vercel this
// is skipped and `reload()` does the real work per request.
if (!usingPostgres) store = loadFromFile();

/* ------------------------------------------------------------------ */
/* Document API — unchanged, still synchronous                         */
/* ------------------------------------------------------------------ */

export function insert<T extends Record<string, unknown>>(
  table: TableName,
  fields: T,
): Doc<T> {
  const doc: Doc<T> = { ...fields, _id: randomUUID(), _creationTime: Date.now() };
  store[table].push(doc as Doc<Record<string, unknown>>);
  persist();
  return doc;
}

export function get<T = Record<string, unknown>>(table: TableName, id: string): Doc<T> | null {
  const doc = store[table].find((d) => d._id === id);
  return (doc as Doc<T> | undefined) ?? null;
}

export function patch<T extends Record<string, unknown>>(
  table: TableName,
  id: string,
  partial: Partial<T>,
): Doc<T> | null {
  const index = store[table].findIndex((d) => d._id === id);
  if (index === -1) return null;
  const updated = { ...store[table][index], ...partial };
  store[table][index] = updated;
  persist();
  return updated as Doc<T>;
}

export function remove(table: TableName, id: string): boolean {
  const before = store[table].length;
  store[table] = store[table].filter((d) => d._id !== id);
  persist();
  return store[table].length !== before;
}

export function all<T = Record<string, unknown>>(table: TableName): Doc<T>[] {
  return store[table] as Doc<T>[];
}

export function find<T = Record<string, unknown>>(
  table: TableName,
  predicate: (doc: Doc<T>) => boolean,
): Doc<T>[] {
  return (store[table] as Doc<T>[]).filter(predicate);
}

export function findOne<T = Record<string, unknown>>(
  table: TableName,
  predicate: (doc: Doc<T>) => boolean,
): Doc<T> | null {
  return (store[table] as Doc<T>[]).find(predicate) ?? null;
}

/** Newest-first, matching Convex's `.order("desc")` default used throughout. */
export function sortDesc<T extends { _creationTime: number }>(docs: T[]): T[] {
  return [...docs].sort((a, b) => b._creationTime - a._creationTime);
}

export function sortAsc<T extends { _creationTime: number }>(docs: T[]): T[] {
  return [...docs].sort((a, b) => a._creationTime - b._creationTime);
}

/** Test-only escape hatch; not used by routes. */
export function _resetForTests(): void {
  store = emptyStore();
  dirty = false;
}
