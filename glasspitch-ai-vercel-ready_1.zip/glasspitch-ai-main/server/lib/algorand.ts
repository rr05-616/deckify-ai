/**
 * Algorand network config + on-chain payment verification.
 *
 * Ported near-verbatim from the original `src/convex/payments.ts` — the
 * verification rules (confirmed on-chain, sender matches, receiver is ours,
 * amount is enough) are unchanged, only the storage calls around them moved
 * from Convex mutations to plain functions called by Hono routes.
 */

export const PREMIUM_DECK_ALGO = 2.5;
export const FOUNDER_ALGO = 19;

const DEFAULT_TESTNET_RECEIVER = "GD64YIY3TWGDMCNPP553DZPPR6LDUSFQOIJVFDPPXWEG3FVOJCCDBBHU5A";
const DEFAULT_MAINNET_RECEIVER = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY5HFKQ";

export interface X402Network {
  network: "testnet" | "mainnet";
  genesisID: string;
  algodUrl: string;
  indexerUrl: string;
}

export function getNetwork(): X402Network {
  const network =
    (process.env.ALGORAND_NETWORK ?? "testnet").toLowerCase() === "mainnet" ? "mainnet" : "testnet";
  return network === "mainnet"
    ? {
        network,
        genesisID: "mainnet-v1.0",
        algodUrl: process.env.ALGORAND_ALGOD_URL ?? "https://mainnet-api.algonode.cloud",
        indexerUrl: process.env.ALGORAND_INDEXER_URL ?? "https://mainnet-idx.algonode.cloud",
      }
    : {
        network,
        genesisID: "testnet-v1.0",
        algodUrl: process.env.ALGORAND_ALGOD_URL ?? "https://testnet-api.algonode.cloud",
        indexerUrl: process.env.ALGORAND_INDEXER_URL ?? "https://testnet-idx.algonode.cloud",
      };
}

export function getReceiverAddress(): string {
  const configured = process.env.ALGORAND_RECEIVER_ADDRESS?.trim();
  if (configured) return configured;
  return getNetwork().network === "mainnet" ? DEFAULT_MAINNET_RECEIVER : DEFAULT_TESTNET_RECEIVER;
}

export function isValidAlgorandAddress(address: string): boolean {
  return /^[A-Z2-7]{40,58}$/.test(address);
}

export function isValidTxHash(hash: string): boolean {
  return /^[A-Z2-7]{52,58}$/.test(hash) || /^[a-f0-9]{64}$/i.test(hash);
}

interface IndexerTransaction {
  "confirmed-round"?: number;
  sender?: string;
  "payment-transaction"?: { receiver?: string; amount?: number };
}

/**
 * Look a transaction up on the AlgoNode indexer and confirm it really paid
 * `requiredMicroAlgos` (or more) from `expectedSender` to our receiver.
 * Throws a user-facing message on any mismatch — same rules the original
 * Convex `verifyX402Payment` enforced.
 */
export async function verifyAlgoPaymentOnChain(
  hash: string,
  expectedSender: string,
  requiredMicroAlgos: number,
): Promise<{ confirmedRound: number }> {
  const net = getNetwork();
  const receiver = getReceiverAddress();

  let tx: IndexerTransaction | undefined;
  try {
    const res = await fetch(`${net.indexerUrl}/v2/transactions/${hash}`, {
      headers: { Accept: "application/json" },
    });
    if (res.status === 404) {
      throw new Error("Transaction not found on-chain — double-check the hash.");
    }
    if (!res.ok) throw new Error(`Indexer error (${res.status}) — try again in a moment.`);
    const body = (await res.json()) as { transaction?: IndexerTransaction };
    tx = body?.transaction;
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("Transaction not found")) throw error;
    throw new Error("Could not reach the Algorand indexer — check your connection.");
  }

  if (!tx) throw new Error("Transaction not found on-chain — double-check the hash.");
  const confirmedRound = tx["confirmed-round"];
  if (!confirmedRound || confirmedRound <= 0) {
    throw new Error("Transaction is not confirmed on-chain yet — wait a few seconds and retry.");
  }
  if (tx.sender !== expectedSender) {
    throw new Error("Sender mismatch — the transaction was not sent by the connected wallet.");
  }

  const pay = tx["payment-transaction"];
  if (!pay) throw new Error("This is not a payment transaction.");
  if (pay.receiver !== receiver) {
    throw new Error("Receiver mismatch — the payment did not go to Deckify's wallet.");
  }
  const paid = Number(pay.amount ?? 0);
  if (paid < requiredMicroAlgos) {
    throw new Error(`Insufficient payment — expected ${requiredMicroAlgos} microAlgos, received ${paid}.`);
  }

  return { confirmedRound };
}
