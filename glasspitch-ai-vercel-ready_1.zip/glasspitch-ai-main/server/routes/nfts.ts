/** NFT minting records — ported from `src/convex/nfts.ts`. */

import { Hono } from "hono";
import { find, findOne, insert, sortDesc } from "../lib/db.js";
import { HttpError, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const nftsRoutes = new Hono();

interface Nft {
  deckId: string;
  userId: string;
  assetId: number;
  txHash: string;
  metadataHash: string;
  network: string;
  creatorAddress: string;
  assetName: string;
  unitName: string;
  metadataUrl: string;
  status: "pending" | "confirmed" | "failed";
}

function userOf(c: { get: (key: "user") => PublicUser | null }): PublicUser {
  const user = c.get("user");
  if (!user) throw new HttpError("Not signed in", 401);
  return user;
}

nftsRoutes.post("/", requireAuth, async (c) => {
  const user = userOf(c);
  const body = await c.req.json<Omit<Nft, "userId" | "status">>();

  const existing = findOne<Nft>("nfts", (n) => n.deckId === body.deckId);
  if (existing) throw new HttpError("This deck has already been minted as an NFT.", 400);

  const nft = insert<Nft>("nfts", { ...body, userId: user._id, status: "confirmed" });
  return c.json({ nftId: nft._id, assetId: nft.assetId, status: "confirmed" });
});

nftsRoutes.get("/deck/:deckId", async (c) => {
  const nft = findOne<Nft>("nfts", (n) => n.deckId === c.req.param("deckId"));
  return c.json(nft ?? null);
});

nftsRoutes.get("/mine", requireAuth, async (c) => {
  const user = userOf(c);
  return c.json(sortDesc(find<Nft>("nfts", (n) => n.userId === user._id)));
});
