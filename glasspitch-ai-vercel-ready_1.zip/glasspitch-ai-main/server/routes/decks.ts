/**
 * Decks + projects — ported from `src/convex/decks.ts`.
 *
 * Deck *content* (sections, insights, readiness score) is computed entirely
 * client-side by `src/lib/deck.ts::buildDeck` — this route only ever
 * receives an already-built deck object to store, exactly like the
 * original Convex mutation did. No AI/LLM call happens on this server.
 */

import { Hono } from "hono";
import { randomBytes } from "node:crypto";
import { find, findOne, get, insert, patch, remove, sortDesc } from "../lib/db.js";
import { HttpError, optionalAuth, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const decksRoutes = new Hono();

interface Deck {
  ownerId: string;
  projectId?: string;
  projectName: string;
  title: string;
  tagline: string;
  shareCode: string;
  sections: unknown[];
  stats: unknown;
  insights: unknown;
  readiness: unknown;
  template?: string;
  published?: boolean;
}

function makeShareCode(): string {
  const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
  const bytes = randomBytes(10);
  let code = "";
  for (const byte of bytes) code += alphabet[byte % alphabet.length];
  return code;
}

function userOf(c: { get: (key: "user") => PublicUser | null }): PublicUser {
  const user = c.get("user");
  if (!user) throw new HttpError("Not signed in", 401);
  return user;
}

// ---- create / delete ------------------------------------------------------

decksRoutes.post("/", requireAuth, async (c) => {
  const user = userOf(c);
  const body = await c.req.json();

  const plan = user.plan ?? "free";
  if (plan !== "pro") {
    const owned = find<Deck>("decks", (d) => d.ownerId === user._id);
    if (owned.length >= 2) {
      throw new HttpError(
        "Free plan limit reached — upgrade to Founder for unlimited decks (Wallet → upgrade).",
        403,
      );
    }
  }

  const existingProject = findOne<{ ownerId: string; name: string }>(
    "projects",
    (p) => p.ownerId === user._id && p.name === body.projectName,
  );

  let projectId: string;
  if (existingProject) {
    projectId = existingProject._id;
    patch("projects", projectId, { sourceMarkdown: body.sourceMarkdown });
  } else {
    const project = insert("projects", {
      ownerId: user._id,
      name: body.projectName,
      sourceMarkdown: body.sourceMarkdown,
    });
    projectId = project._id;
  }

  const deck = insert<Deck>("decks", {
    ownerId: user._id,
    projectId,
    projectName: body.projectName,
    title: body.title,
    tagline: body.tagline,
    shareCode: makeShareCode(),
    sections: body.sections,
    stats: body.stats,
    insights: body.insights,
    readiness: body.readiness,
    template: body.template ?? "glass",
  });

  return c.json({ projectId, deckId: deck._id });
});

decksRoutes.delete("/:deckId", requireAuth, async (c) => {
  const user = userOf(c);
  const deckId = c.req.param("deckId");
  const deck = get<Deck>("decks", deckId);
  if (!deck || deck.ownerId !== user._id) throw new HttpError("Not found", 404);

  remove("decks", deckId);

  if (deck.projectId) {
    const siblings = find<Deck>("decks", (d) => d.projectId === deck.projectId);
    if (siblings.length === 0) {
      const project = get("projects", deck.projectId);
      if (project && (project as { ownerId: string }).ownerId === user._id) {
        remove("projects", deck.projectId);
      }
    }
  }

  return c.json({ ok: true });
});

// ---- projects ---------------------------------------------------------

decksRoutes.get("/projects/mine", requireAuth, async (c) => {
  const user = userOf(c);
  const projects = find("projects", (p) => (p as { ownerId: string }).ownerId === user._id);
  return c.json(sortDesc(projects));
});

decksRoutes.delete("/projects/:projectId", requireAuth, async (c) => {
  const user = userOf(c);
  const projectId = c.req.param("projectId");
  const project = get<{ ownerId: string }>("projects", projectId);
  if (!project || project.ownerId !== user._id) throw new HttpError("Not found", 404);

  const decks = find<Deck>("decks", (d) => d.projectId === projectId);
  for (const deck of decks) remove("decks", deck._id);
  remove("projects", projectId);

  return c.json({ ok: true });
});

// ---- reads --------------------------------------------------------------

decksRoutes.get("/", requireAuth, async (c) => {
  const user = userOf(c);
  const decks = find<Deck>("decks", (d) => d.ownerId === user._id);
  return c.json(sortDesc(decks));
});

decksRoutes.get("/catalog", optionalAuth, async (c) => {
  const query = (c.req.query("query") ?? "").trim().toLowerCase();
  const published = sortDesc(find<Deck>("decks", (d) => d.published === true));
  if (!query) return c.json(published);

  const terms = query.split(/\s+/);
  const filtered = published.filter((d) => {
    const haystack = `${d.title} ${d.tagline} ${d.projectName}`.toLowerCase();
    return terms.every((term) => haystack.includes(term));
  });
  return c.json(filtered);
});

decksRoutes.get("/share/:shareCode", optionalAuth, async (c) => {
  const shareCode = c.req.param("shareCode");
  const deck = findOne<Deck>("decks", (d) => d.shareCode === shareCode);
  return c.json(deck ?? null);
});

decksRoutes.get("/:deckId", requireAuth, async (c) => {
  const user = userOf(c);
  const deck = get<Deck>("decks", c.req.param("deckId"));
  if (!deck || deck.ownerId !== user._id) return c.json(null);
  return c.json(deck);
});

// ---- updates --------------------------------------------------------------

decksRoutes.patch("/:deckId/template", requireAuth, async (c) => {
  const user = userOf(c);
  const deckId = c.req.param("deckId");
  const deck = get<Deck>("decks", deckId);
  if (!deck) throw new HttpError("Not found", 404);
  if (deck.ownerId !== user._id && user.role !== "admin") {
    throw new HttpError("Not allowed", 403);
  }
  const { template } = await c.req.json<{ template: string }>();
  patch("decks", deckId, { template });
  return c.json(template);
});

decksRoutes.patch("/:deckId/publish", requireAuth, async (c) => {
  const user = userOf(c);
  const deckId = c.req.param("deckId");
  const deck = get<Deck>("decks", deckId);
  if (!deck) throw new HttpError("Not found", 404);
  if (deck.ownerId !== user._id && user.role !== "admin") {
    throw new HttpError("Not allowed", 403);
  }
  const { published } = await c.req.json<{ published: boolean }>();
  patch("decks", deckId, { published });
  return c.json(published);
});
