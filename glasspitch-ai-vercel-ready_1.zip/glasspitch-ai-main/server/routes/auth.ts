/**
 * Auth routes — replaces Convex Auth (email OTP + anonymous + Google/GitHub).
 *
 * Email OTP has no external email provider wired in (the original used
 * freebuff's hosted send-OTP API with a key this project doesn't own). In
 * development the code is logged to the server console and echoed back as
 * `devCode` in the response; wire in a real mailer via `sendOtpEmail` below
 * before deploying somewhere the console isn't visible to the user.
 */

import { Hono } from "hono";
import { generateOtp, issueToken, otpExpiresAt, otpMatches } from "../lib/auth.js";
import { findOne, insert, patch, remove } from "../lib/db.js";
import { HttpError, optionalAuth, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const authRoutes = new Hono();

/** Swap in a real provider (Resend, Postmark, SMTP...) when you have one. */
async function sendOtpEmail(email: string, code: string): Promise<void> {
  console.log(`[auth] OTP for ${email}: ${code}`);
}

function findUserByEmail(email: string): PublicUser | null {
  return findOne<PublicUser>("users", (u) => u.email === email);
}

function toPublicUser(doc: PublicUser): PublicUser {
  return doc;
}

/**
 * Two-phase, mirroring the original `signIn("email-otp", formData)` calls:
 *   phase 1 — { email }         -> generate + "send" a code
 *   phase 2 — { email, code }   -> verify, create/find the user, issue a token
 */
authRoutes.post("/email-otp", async (c) => {
  const body = await c.req.json<{ email?: string; code?: string }>().catch(() => ({}));
  const email = (body.email ?? "").trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new HttpError("Enter a valid email address.", 400);
  }

  if (!body.code) {
    const existingOtp = findOne("otps", (o) => (o as { email: string }).email === email);
    if (existingOtp) remove("otps", existingOtp._id);

    const code = generateOtp();
    insert("otps", { email, code, expiresAt: otpExpiresAt() });
    await sendOtpEmail(email, code);

    return c.json({
      ok: true,
      devCode: process.env.NODE_ENV === "production" ? undefined : code,
    });
  }

  const record = findOne<{ email: string; code: string; expiresAt: number }>(
    "otps",
    (o) => o.email === email,
  );
  if (!record || record.expiresAt < Date.now() || !otpMatches(body.code.trim(), record.code)) {
    throw new HttpError("The verification code you entered is incorrect.", 400);
  }
  remove("otps", record._id);

  let user = findUserByEmail(email);
  if (!user) {
    user = insert<Record<string, unknown>>("users", {
      email,
      emailVerificationTime: Date.now(),
      isAnonymous: false,
      role: "user",
      plan: "free",
    }) as PublicUser;
  } else if (!user.emailVerificationTime) {
    user = patch<PublicUser>("users", user._id, { emailVerificationTime: Date.now() }) as PublicUser;
  }

  return c.json({ ok: true, token: issueToken(user._id), user: toPublicUser(user) });
});

authRoutes.post("/guest", async (c) => {
  const user = insert<Record<string, unknown>>("users", {
    isAnonymous: true,
    role: "user",
    plan: "free",
    name: "Guest",
  }) as PublicUser;
  return c.json({ ok: true, token: issueToken(user._id), user: toPublicUser(user) });
});

authRoutes.post("/logout", requireAuth, async (c) => {
  // Tokens are stateless (HMAC-signed, not stored), so there is nothing to
  // revoke server-side yet. This endpoint exists so the client always has
  // something to call, and so a future token-blacklist can slot in here
  // without any frontend changes.
  return c.json({ ok: true });
});

authRoutes.get("/me", optionalAuth, async (c) => {
  const user = c.get("user") as PublicUser | null;
  return c.json({ user: user ? toPublicUser(user) : null });
});

/** Lets the frontend decide "redirect to Google" vs "show a helpful error" before navigating away. */
authRoutes.get("/oauth/:provider/status", async (c) => {
  const provider = c.req.param("provider");
  const configured =
    provider === "google"
      ? Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET)
      : provider === "github"
        ? Boolean(process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET)
        : false;
  return c.json({ configured });
});

const OAUTH_ENDPOINTS = {
  google: {
    authorize: "https://accounts.google.com/o/oauth2/v2/auth",
    token: "https://oauth2.googleapis.com/token",
    userinfo: "https://openidconnect.googleapis.com/v1/userinfo",
    scope: "openid email profile",
  },
  github: {
    authorize: "https://github.com/login/oauth/authorize",
    token: "https://github.com/login/oauth/access_token",
    userinfo: "https://api.github.com/user",
    scope: "read:user user:email",
  },
} as const;

function backendUrl(c: { req: { url: string } }): string {
  return process.env.BACKEND_URL ?? new URL(c.req.url).origin;
}

authRoutes.get("/oauth/:provider/start", async (c) => {
  const provider = c.req.param("provider") as "google" | "github";
  const endpoints = OAUTH_ENDPOINTS[provider];
  if (!endpoints) throw new HttpError("Unknown provider", 404);

  const clientId =
    provider === "google" ? process.env.GOOGLE_CLIENT_ID : process.env.GITHUB_CLIENT_ID;
  if (!clientId) {
    throw new HttpError(
      `${provider === "google" ? "Google" : "GitHub"} sign-in isn't configured yet.`,
      400,
    );
  }

  const redirectTo = c.req.query("redirectTo") ?? "/dashboard";
  const redirectUri = `${backendUrl(c)}/api/auth/oauth/${provider}/callback`;
  const state = Buffer.from(JSON.stringify({ redirectTo })).toString("base64url");

  const url = new URL(endpoints.authorize);
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("scope", endpoints.scope);
  url.searchParams.set("state", state);
  if (provider === "google") {
    url.searchParams.set("response_type", "code");
    url.searchParams.set("access_type", "online");
  }

  return c.redirect(url.toString());
});

authRoutes.get("/oauth/:provider/callback", async (c) => {
  const provider = c.req.param("provider") as "google" | "github";
  const endpoints = OAUTH_ENDPOINTS[provider];
  const frontendUrl = process.env.FRONTEND_URL ?? "http://localhost:5173";
  if (!endpoints) throw new HttpError("Unknown provider", 404);

  const code = c.req.query("code");
  const stateRaw = c.req.query("state");
  const redirectTo = (() => {
    try {
      return stateRaw
        ? (JSON.parse(Buffer.from(stateRaw, "base64url").toString("utf-8")) as { redirectTo?: string })
            .redirectTo ?? "/dashboard"
        : "/dashboard";
    } catch {
      return "/dashboard";
    }
  })();

  if (!code) return c.redirect(`${frontendUrl}/auth?error=oauth_failed`);

  const clientId =
    provider === "google" ? process.env.GOOGLE_CLIENT_ID! : process.env.GITHUB_CLIENT_ID!;
  const clientSecret =
    provider === "google" ? process.env.GOOGLE_CLIENT_SECRET! : process.env.GITHUB_CLIENT_SECRET!;
  const redirectUri = `${backendUrl(c)}/api/auth/oauth/${provider}/callback`;

  try {
    const tokenRes = await fetch(endpoints.token, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        code,
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      }),
    });
    if (!tokenRes.ok) throw new Error("token exchange failed");
    const tokenBody = (await tokenRes.json()) as { access_token?: string };
    if (!tokenBody.access_token) throw new Error("no access token returned");

    const profileRes = await fetch(endpoints.userinfo, {
      headers: { Authorization: `Bearer ${tokenBody.access_token}`, Accept: "application/json" },
    });
    if (!profileRes.ok) throw new Error("profile fetch failed");
    const profile = (await profileRes.json()) as Record<string, unknown>;

    const email =
      (typeof profile.email === "string" && profile.email) ||
      (await fetchGithubPrimaryEmail(provider, tokenBody.access_token)) ||
      undefined;
    const name = (profile.name as string) || (profile.login as string) || undefined;
    const image = (profile.picture as string) || (profile.avatar_url as string) || undefined;

    let user = email ? findUserByEmail(email) : null;
    if (!user) {
      user = insert<Record<string, unknown>>("users", {
        email,
        name,
        image,
        isAnonymous: false,
        role: "user",
        plan: "free",
        emailVerificationTime: email ? Date.now() : undefined,
      }) as PublicUser;
    }

    const token = issueToken(user._id);
    const redirectUrl = new URL(redirectTo.startsWith("/") ? redirectTo : "/dashboard", frontendUrl);
    redirectUrl.searchParams.set("token", token);
    return c.redirect(redirectUrl.toString());
  } catch (error) {
    console.error(`[auth] ${provider} OAuth callback failed:`, error);
    return c.redirect(`${frontendUrl}/auth?error=oauth_failed`);
  }
});

async function fetchGithubPrimaryEmail(
  provider: "google" | "github",
  accessToken: string,
): Promise<string | undefined> {
  if (provider !== "github") return undefined;
  try {
    const res = await fetch("https://api.github.com/user/emails", {
      headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
    });
    if (!res.ok) return undefined;
    const emails = (await res.json()) as Array<{ email: string; primary: boolean; verified: boolean }>;
    return emails.find((e) => e.primary && e.verified)?.email ?? emails[0]?.email;
  } catch {
    return undefined;
  }
}
