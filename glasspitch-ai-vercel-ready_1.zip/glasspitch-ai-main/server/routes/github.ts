/** GitHub repo ingestion endpoint — thin wrapper over lib/github.ts. */

import { Hono } from "hono";
import { fetchGithubRepo } from "../lib/github.js";
import { HttpError } from "../lib/http.js";

export const githubRoutes = new Hono();

githubRoutes.post("/fetch", async (c) => {
  const { url } = await c.req.json<{ url: string }>();
  if (!url || typeof url !== "string") throw new HttpError("A repository URL is required.", 400);

  try {
    const result = await fetchGithubRepo(url);
    return c.json(result);
  } catch (error) {
    throw new HttpError(error instanceof Error ? error.message : "Could not fetch that repository.", 400);
  }
});
