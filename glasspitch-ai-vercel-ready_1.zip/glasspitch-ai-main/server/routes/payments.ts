/**
 * Algorand x402 payments — ported from `src/convex/payments.ts`.
 *
 * This is the "wallet-connect and verify" payment path used by the Founder
 * upgrade and the per-deck unlock dialog (Wallet.tsx / DeckView.tsx). It is
 * separate from `x402-demo-server/`, which handles a second, independent
 * USDC-denominated payment path the frontend calls directly — that server
 * is untouched by this migration.
 */

import { Hono } from "hono";
import {
  FOUNDER_ALGO,
  PREMIUM_DECK_ALGO,
  getNetwork,
  getReceiverAddress,
  isValidAlgorandAddress,
  isValidTxHash,
  verifyAlgoPaymentOnChain,
} from "../lib/algorand.js";
import { find, get, insert, patch } from "../lib/db.js";
import { HttpError, optionalAuth, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const paymentsRoutes = new Hono();

interface Payment {
  userId: string;
  deckId?: string;
  walletAddress: string;
  txHash: string;
  amount: number;
  assetId: number;
  status: "authorized" | "verified" | "failed";
  network?: string;
  confirmedRound?: number;
  memo?: string;
}

function userOf(c: { get: (key: "user") => PublicUser | null }): PublicUser {
  const user = c.get("user");
  if (!user) throw new HttpError("Not signed in", 401);
  return user;
}

paymentsRoutes.get("/config", optionalAuth, async (c) => {
  const net = getNetwork();
  return c.json({
    network: net.network,
    genesisID: net.genesisID,
    algodUrl: net.algodUrl,
    indexerUrl: net.indexerUrl,
    receiverAddress: getReceiverAddress(),
    amountAlgo: PREMIUM_DECK_ALGO,
    amountMicro: Math.round(PREMIUM_DECK_ALGO * 1_000_000),
    assetId: 0,
    explorerBase: `https://${net.network === "testnet" ? "testnet." : ""}explorer.perawallet.app`,
  });
});

paymentsRoutes.post("/authorize", requireAuth, async (c) => {
  const user = userOf(c);
  const body = await c.req.json<{ walletAddress: string; deckId?: string; memo?: string }>();
  const address = body.walletAddress.trim();
  if (!isValidAlgorandAddress(address)) {
    throw new HttpError("Invalid Algorand address — expected 58-char base32 format.", 400);
  }

  const net = getNetwork();
  const payment = insert<Payment>("payments", {
    userId: user._id,
    deckId: body.deckId,
    walletAddress: address,
    txHash: "",
    amount: Math.round(PREMIUM_DECK_ALGO * 1_000_000),
    assetId: 0,
    status: "authorized",
    network: net.network,
    memo: body.memo ?? "Deckify AI — premium deck generation",
  });

  return c.json({
    paymentId: payment._id,
    amountAlgo: PREMIUM_DECK_ALGO,
    amountMicro: Math.round(PREMIUM_DECK_ALGO * 1_000_000),
    assetId: 0,
    receiverAddress: getReceiverAddress(),
    network: net.network,
  });
});

paymentsRoutes.post("/founder/authorize", requireAuth, async (c) => {
  const user = userOf(c);
  if (user.plan === "pro") throw new HttpError("You are already on the Founder plan.", 400);

  const body = await c.req.json<{ walletAddress: string }>();
  const address = body.walletAddress.trim();
  if (!isValidAlgorandAddress(address)) {
    throw new HttpError("Invalid Algorand address — expected 58-char base32 format.", 400);
  }

  const net = getNetwork();
  const amountMicro = Math.round(FOUNDER_ALGO * 1_000_000);
  const payment = insert<Payment>("payments", {
    userId: user._id,
    walletAddress: address,
    txHash: "",
    amount: amountMicro,
    assetId: 0,
    status: "authorized",
    network: net.network,
    memo: "Deckify AI — Founder upgrade via x402",
  });

  return c.json({
    paymentId: payment._id,
    amountAlgo: FOUNDER_ALGO,
    amountMicro,
    assetId: 0,
    receiverAddress: getReceiverAddress(),
    network: net.network,
  });
});

paymentsRoutes.post("/verify", requireAuth, async (c) => {
  const user = userOf(c);
  const { paymentId, txHash } = await c.req.json<{ paymentId: string; txHash: string }>();

  const payment = get<Payment>("payments", paymentId);
  if (!payment || payment.userId !== user._id) throw new HttpError("Payment not found", 404);
  if (payment.status === "verified") {
    return c.json({ paymentId: payment._id, status: "verified" });
  }

  const hash = txHash.trim();
  if (!isValidTxHash(hash)) throw new HttpError("Invalid transaction hash.", 400);

  try {
    const { confirmedRound } = await verifyAlgoPaymentOnChain(hash, payment.walletAddress, payment.amount);
    patch("payments", payment._id, {
      status: "verified",
      txHash: hash,
      network: getNetwork().network,
      confirmedRound,
    });

    if (payment.memo?.includes("Founder upgrade")) {
      patch("users", user._id, { plan: "pro" });
    }

    return c.json({ paymentId: payment._id, status: "verified", confirmedRound });
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("Transaction not found")) {
      patch("payments", payment._id, { status: "failed" });
    }
    throw new HttpError(error instanceof Error ? error.message : "Could not verify payment.", 400);
  }
});

paymentsRoutes.post("/record-unlock", requireAuth, async (c) => {
  const user = userOf(c);
  const body = await c.req.json<{
    deckId?: string;
    walletAddress: string;
    txHash: string;
    amountUsd: number;
    assetId: number;
    network: string;
    confirmedRound?: number;
  }>();

  const hash = body.txHash.trim();
  if (!hash) throw new HttpError("Missing transaction hash.", 400);
  if (!isValidTxHash(hash)) throw new HttpError("Invalid transaction hash.", 400);

  if (body.deckId) {
    const deck = get<{ ownerId: string }>("decks", body.deckId);
    if (!deck) throw new HttpError("Deck not found", 404);
    if (deck.ownerId !== user._id) throw new HttpError("You don't own this deck", 403);

    const existing = find<Payment>(
      "payments",
      (p) => p.deckId === body.deckId && p.status === "verified",
    );
    if (existing.length > 0) {
      return c.json({ status: "already-unlocked", paymentId: existing[0]._id });
    }
  }

  const payment = insert<Payment>("payments", {
    userId: user._id,
    deckId: body.deckId,
    walletAddress: body.walletAddress.trim(),
    txHash: hash,
    amount: Math.round(body.amountUsd * 1_000_000),
    assetId: body.assetId,
    status: "verified",
    network: body.network,
    confirmedRound: body.confirmedRound,
    memo: "Deckify AI — premium deck via x402 server",
  });

  return c.json({ status: "verified", paymentId: payment._id });
});

paymentsRoutes.get("/", requireAuth, async (c) => {
  const user = userOf(c);
  const payments = find<Payment>("payments", (p) => p.userId === user._id);
  return c.json([...payments].sort((a, b) => b._creationTime - a._creationTime));
});

paymentsRoutes.get("/deck/:deckId/unlocked", optionalAuth, async (c) => {
  const user = c.get("user") as PublicUser | null;
  if (!user) return c.json({ unlocked: false, verified: [] });

  const deckId = c.req.param("deckId");
  const verified = find<Payment>("payments", (p) => p.deckId === deckId && p.status === "verified");

  return c.json({
    unlocked: verified.length > 0,
    verified: verified.map((p) => ({
      walletAddress: p.walletAddress,
      txHash: p.txHash,
      amount: p.amount,
      status: p.status,
      network: p.network,
      confirmedRound: p.confirmedRound,
      creationTime: p._creationTime,
    })),
  });
});
