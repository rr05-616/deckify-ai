/** Deck comments — ported from `src/convex/comments.ts`. */

import { Hono } from "hono";
import { find, get, insert, remove, sortAsc } from "../lib/db.js";
import { HttpError, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const commentsRoutes = new Hono();

interface Comment {
  deckId: string;
  authorId: string;
  authorName: string;
  body: string;
}

function userOf(c: { get: (key: "user") => PublicUser | null }): PublicUser {
  const user = c.get("user");
  if (!user) throw new HttpError("Not signed in", 401);
  return user;
}

commentsRoutes.get("/deck/:deckId", async (c) => {
  const deckId = c.req.param("deckId");
  return c.json(sortAsc(find<Comment>("comments", (cm) => cm.deckId === deckId)));
});

commentsRoutes.post("/deck/:deckId", requireAuth, async (c) => {
  const user = userOf(c);
  const deckId = c.req.param("deckId");
  const { body } = await c.req.json<{ body: string }>();

  const trimmed = body.trim();
  if (trimmed.length < 2) throw new HttpError("Comment too short", 400);
  if (trimmed.length > 500) throw new HttpError("Comment too long", 400);

  const deck = get("decks", deckId);
  if (!deck) throw new HttpError("Deck not found", 404);

  const authorName = user.name || user.email?.split("@")[0] || "Guest";
  const comment = insert<Comment>("comments", { deckId, authorId: user._id, authorName, body: trimmed });
  return c.json(comment._id);
});

commentsRoutes.delete("/:commentId", requireAuth, async (c) => {
  const user = userOf(c);
  const commentId = c.req.param("commentId");
  const comment = get<Comment>("comments", commentId);
  if (!comment) throw new HttpError("Not found", 404);

  const isAdmin = user.role === "admin";
  if (comment.authorId !== user._id && !isAdmin) throw new HttpError("Not allowed", 403);

  remove("comments", commentId);
  return c.json({ ok: true });
});
