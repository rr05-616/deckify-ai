/**
 * Billing — ported from `src/convex/billing.ts`.
 *
 * The original file also had a Stripe Checkout action (`createCheckoutSession`)
 * and a `markPro` mutation, but neither is called from any page — the app's
 * only real upgrade path is the Algorand Founder payment in
 * `routes/payments.ts`, which already grants `plan: "pro"` on verification.
 * Only the read side (`getBilling`) is actually reachable from the UI, so
 * that's all that's ported here; nothing is lost from what the app uses.
 */

import { Hono } from "hono";
import { find } from "../lib/db.js";
import { HttpError, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const billingRoutes = new Hono();

billingRoutes.get("/", requireAuth, async (c) => {
  const user = c.get("user") as PublicUser | null;
  if (!user) throw new HttpError("Not signed in", 401);

  const deckCount = find("decks", (d) => (d as { ownerId: string }).ownerId === user._id).length;
  return c.json({
    plan: user.plan ?? "free",
    email: user.email ?? "",
    deckCount,
    isAdmin: user.role === "admin",
  });
});
