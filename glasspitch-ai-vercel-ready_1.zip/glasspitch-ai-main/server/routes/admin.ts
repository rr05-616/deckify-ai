/** Admin console — ported from `src/convex/admin.ts`. */

import { Hono } from "hono";
import { all, find, get, patch, remove, sortDesc } from "../lib/db.js";
import { HttpError, requireAdmin, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const adminRoutes = new Hono();

interface Deck {
  ownerId: string;
  projectId?: string;
}

adminRoutes.use("*", requireAuth);

adminRoutes.get("/users", async (c) => {
  requireAdmin(c.get("user") as PublicUser | null);
  return c.json(sortDesc(all("users")));
});

adminRoutes.patch("/users/:userId", async (c) => {
  requireAdmin(c.get("user") as PublicUser | null);
  const userId = c.req.param("userId");
  const target = get("users", userId);
  if (!target) throw new HttpError("User not found", 404);

  const body = await c.req.json<{ role?: "admin" | "user" | "member"; plan?: "free" | "pro" }>();
  patch("users", userId, {
    ...(body.role ? { role: body.role } : {}),
    ...(body.plan ? { plan: body.plan } : {}),
  });
  return c.json({ ok: true });
});

adminRoutes.get("/decks", async (c) => {
  requireAdmin(c.get("user") as PublicUser | null);
  return c.json(sortDesc(all("decks")));
});

adminRoutes.delete("/decks/:deckId", async (c) => {
  requireAdmin(c.get("user") as PublicUser | null);
  const deckId = c.req.param("deckId");
  const deck = get<Deck>("decks", deckId);
  if (!deck) throw new HttpError("Deck not found", 404);

  remove("decks", deckId);
  if (deck.projectId) {
    const siblings = find<Deck>("decks", (d) => d.projectId === deck.projectId);
    if (siblings.length === 0) remove("projects", deck.projectId);
  }
  return c.json({ ok: true });
});

adminRoutes.get("/comments", async (c) => {
  requireAdmin(c.get("user") as PublicUser | null);
  return c.json(sortDesc(all("comments")));
});

adminRoutes.delete("/comments/:commentId", async (c) => {
  requireAdmin(c.get("user") as PublicUser | null);
  remove("comments", c.req.param("commentId"));
  return c.json({ ok: true });
});
