/** Profile + wallet settings — ported from `src/convex/settings.ts`. */

import { Hono } from "hono";
import { patch } from "../lib/db.js";
import { HttpError, requireAuth } from "../lib/http.js";
import type { PublicUser } from "../lib/auth.js";

export const settingsRoutes = new Hono();

function userOf(c: { get: (key: "user") => PublicUser | null }): PublicUser {
  const user = c.get("user");
  if (!user) throw new HttpError("Not signed in", 401);
  return user;
}

settingsRoutes.get("/", requireAuth, async (c) => {
  const user = userOf(c);
  return c.json({
    name: user.name ?? "",
    image: user.image ?? "",
    email: user.email ?? "",
    bio: user.bio ?? "",
    walletAddress: user.walletAddress ?? "",
    plan: user.plan ?? "free",
    role: user.role ?? "user",
    isAnonymous: user.isAnonymous ?? false,
  });
});

settingsRoutes.patch("/profile", requireAuth, async (c) => {
  const user = userOf(c);
  const body = await c.req.json<{ name?: string; image?: string; bio?: string }>();

  const patchFields: { name?: string; image?: string; bio?: string } = {};
  if (body.name !== undefined) {
    const name = body.name.trim().slice(0, 60);
    if (name.length < 2) throw new HttpError("Name must be at least 2 characters.", 400);
    patchFields.name = name;
  }
  if (body.image !== undefined) {
    patchFields.image = body.image.trim().slice(0, 500) || undefined;
  }
  if (body.bio !== undefined) {
    patchFields.bio = body.bio.trim().slice(0, 240) || undefined;
  }

  patch("users", user._id, patchFields);
  return c.json({ ok: true });
});

settingsRoutes.patch("/wallet", requireAuth, async (c) => {
  const user = userOf(c);
  const { walletAddress } = await c.req.json<{ walletAddress: string }>();
  const address = walletAddress.trim();
  if (!/^[A-Z2-7]{40,58}$/.test(address)) {
    throw new HttpError("Invalid Algorand address — expected 58-char base32 format.", 400);
  }
  patch("users", user._id, { walletAddress: address });
  return c.json({ ok: true });
});
